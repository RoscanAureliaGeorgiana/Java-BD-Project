INSERT into ANGAJATI VALUES (NULL, 'Voroneanu Adina','voroneanu@yahoo.com','0745784215','make-up artist');
INSERT into ANGAJATI VALUES (NULL, 'Ragnea Ramona','ramona.123@yahoo.com','0728754632','make-up artist');
INSERT into ANGAJATI VALUES (NULL, 'Alexandru Delia','delia_alex@yahoo.com','0784569871','make-up artist');
INSERT into ANGAJATI VALUES (NULL, 'Toma Petronela','tomapetronela87@yahoo.com','0747402035','make-up artist');
INSERT into ANGAJATI VALUES (NULL, 'Precupescu Iulia','prec_iulia@yahoo.com','0778785457','make-up artist');
INSERT into ANGAJATI VALUES (NULL, 'Presa Ana',NULL,'0778455457','make-up artist');

SELECT * from ANGAJATI;

INSERT into CURSANTI VALUES(NULL, 'Vulpe Karina', 18,'vulpe@gmail.com', '0785412541');
INSERT into CURSANTI VALUES(NULL, 'Boanta Geanina', 22, 'geani123@yahoo.com',NULL);
INSERT into CURSANTI VALUES(NULL, 'Radu Ioana', 18,NULL,'0785412545');
INSERT into CURSANTI VALUES(NULL, 'Carmen Maria', 18,NULL,NULL);
INSERT into CURSANTI VALUES(NULL,'Scripca Raluca', 20, 'ralu.scripca@yahoo.com','0785442154');
INSERT into CURSANTI VALUES(NULL, 'Lascar Andreea', 20, 'lascar@yahoo.com','0741235002');
INSERT into CURSANTI VALUES(NULL, 'Ioan Ioana', 17, 'ioan.ioana@yahoo.com','0768952103');

SELECT * FROM CURSANTI;

INSERT into TIPURI_PRODUSE VALUES(NULL, 'ruj MAC', 20);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'eyeliner MAC', 40);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'fond de ten LOREAL', 35);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'pudra LOREAL', 35);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'rimmel MELKIOR', 40);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'blush LOREAL',35);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'spray fixare', 25);
INSERT into TIPURI_PRODUSE VALUES(NULL, 'paleta farduri',30);


SELECT * FROM TIPURI_PRODUSE;

INSERT into CURSURI VALUES(NULL,'machiaj zi', 120, '15/01/2020', 10, 800, 'teoretic',
    (SELECT id_angajat FROM ANGAJATI WHERE nume_angajat='Voroneanu Adina'));
INSERT into CURSURI VALUES(NULL,'machiaj seara', 180, '26/02/2020', 7, 1200, 'practic',
    (SELECT id_angajat FROM ANGAJATI WHERE nume_angajat='Ragnea Ramona'));
INSERT into CURSURI VALUES(NULL,'machiaj mireasa', 240, '13/03/2020', 7, 1600, 'practic',
    (SELECT id_angajat FROM ANGAJATI WHERE nume_angajat='Alexandru Delia'));
INSERT into CURSURI VALUES(NULL,'machiaj incepatori', 120, '15/03/2020', 15, 650, 'teoretic',
    (SELECT id_angajat FROM ANGAJATI WHERE nume_angajat='Toma Petronela'));
INSERT into CURSURI VALUES(NULL,'machiaj eyeliner', 90, '20/04/2020', 20, 550, 'practic',
    (SELECT id_angajat FROM ANGAJATI WHERE nume_angajat='Precupescu Iulia'));

SELECT * FROM CURSURI;


INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Boanta Geanina'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj eyeliner'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Scripca Raluca'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj eyeliner'));
INSERT into CURSANT_CURS_FK VALUES(
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Ioan Ioana'),
    (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));

SELECT * FROM CURSANT_CURS_FK;


INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj zi'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='spray fixare'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj seara'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='pudra LOREAL'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='blush LOREAL'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='spray fixare'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj mireasa'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj incepatori'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj eyeliner'));
INSERT into PRODUSE_FOLOSITE VALUES(2,
    (SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'), (SELECT id_curs FROM CURSURI WHERE nume_curs='machiaj eyeliner'));

SELECT * FROM PRODUSE_FOLOSITE;


INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='pudra LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='blush LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Vulpe Karina'),1);

INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Boanta Geanina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Boanta Geanina'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Boanta Geanina'),1);
    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='pudra LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='blush LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='spray fixare'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Radu Ioana'),1);
    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='spray fixare'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Carmen Maria'),1);
    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Scripca Raluca'),1);    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='spray fixare'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Scripca Raluca'),1);    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Scripca Raluca'),1);
    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),1);    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),1);    
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='fond de ten LOREAL'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),1);   
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Lascar Andreea'),1);

INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='ruj MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Ioan Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='eyeliner MAC'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Ioan Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='rimmel MELKIOR'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Ioan Ioana'),1);
INSERT into PRODUSE_ACHIZITIONATE VALUES ((SELECT cod_produs FROM TIPURI_PRODUSE WHERE nume_produs='paleta farduri'),
    (SELECT id_cursant FROM CURSANTI WHERE nume_cursant='Ioan Ioana'),1);
    
SELECT * FROM PRODUSE_ACHIZITIONATE;


