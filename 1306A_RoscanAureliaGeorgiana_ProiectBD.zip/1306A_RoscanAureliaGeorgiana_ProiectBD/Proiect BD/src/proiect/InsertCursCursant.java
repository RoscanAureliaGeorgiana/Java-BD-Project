package proiect;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class InsertCursCursant {
	private JTextField textField;
	private JTextField textField_1;
	
	Connection con=null;
	
	public InsertCursCursant(){
        
		con=Main.dbConnector();
		
        JFrame frmInsert = new JFrame();
		frmInsert.setSize(315,245);
		
		frmInsert.setTitle("Insert");
		frmInsert.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 299, 198);
		frmInsert.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(117, 24, 160, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNume = new JLabel("ID cursant");
		lblNume.setBounds(21, 27, 84, 14);
		panel.add(lblNume);
		
		JLabel lblDurata = new JLabel("ID curs");
		lblDurata.setBounds(21, 73, 84, 14);
		panel.add(lblDurata);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(117, 70, 160, 20);
		panel.add(textField_1);
		
		
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String sql= "INSERT INTO CURSANT_CURS_FK (cursanti_id_cursant, cursuri_id_curs) VALUES (?,?)";
					PreparedStatement pst=con.prepareStatement(sql);
					pst.setString(1, textField.getText());
					pst.setString(2, textField_1.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Date inserate!");
					
					pst.close();
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnNewButton.setBounds(93, 137, 89, 23);
		panel.add(btnNewButton);
		
		
		
		frmInsert.setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new InsertCursCursant();
	}
}
