package proiect;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class InsertProduse {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	Connection con=null; 
	
	public InsertProduse(){
		
		con=Main.dbConnector();
        
        JFrame frmInsert = new JFrame();
		frmInsert.setSize(315,278);
		
		frmInsert.setTitle("Insert");
		frmInsert.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 299, 238);
		frmInsert.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(117, 24, 160, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNume = new JLabel("Nume");
		lblNume.setBounds(21, 68, 46, 14);
		panel.add(lblNume);
		
		JLabel lblDurata = new JLabel("Cantitate");
		lblDurata.setBounds(21, 116, 57, 14);
		panel.add(lblDurata);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(117, 65, 160, 20);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(117, 113, 160, 20);
		panel.add(textField_2);
		
		JLabel lblIdAngajat = new JLabel("Cod");
		lblIdAngajat.setBounds(21, 27, 37, 14);
		panel.add(lblIdAngajat);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String sql= "INSERT INTO TIPURI_PRODUSE (cod_produs, nume_produs, cantitate_produs) VALUES (?,?,?)";
					PreparedStatement pst=con.prepareStatement(sql);
					pst.setString(1, textField.getText());
					pst.setString(2, textField_1.getText());
					pst.setString(3, textField_2.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Date salvate!");
					
					pst.close();
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnNewButton.setBounds(103, 173, 89, 23);
		panel.add(btnNewButton);
		
		frmInsert.setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new InsertProduse();
	}
}
