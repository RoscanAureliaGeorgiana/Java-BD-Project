package proiect;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class InsertCurs {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_6;
	
	Connection con=null;
	private JTextField textField_5;
	
	public InsertCurs(){
        
		con=Main.dbConnector();
		
        JFrame frmInsert = new JFrame();
		frmInsert.setSize(315,422);
		
		frmInsert.setTitle("Insert");
		frmInsert.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 299, 383);
		frmInsert.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(117, 55, 160, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNume = new JLabel("Nume");
		lblNume.setBounds(21, 58, 46, 14);
		panel.add(lblNume);
		
		JLabel lblDurata = new JLabel("Durata");
		lblDurata.setBounds(21, 99, 46, 14);
		panel.add(lblDurata);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(117, 96, 160, 20);
		panel.add(textField_1);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(21, 142, 46, 14);
		panel.add(lblData);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(117, 139, 160, 20);
		panel.add(textField_2);
		
		JLabel lblNrParticipanti = new JLabel("Nr. participanti");
		lblNrParticipanti.setBounds(21, 183, 86, 14);
		panel.add(lblNrParticipanti);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(117, 180, 160, 20);
		panel.add(textField_3);
		
		JLabel lblPret = new JLabel("Pret");
		lblPret.setBounds(21, 216, 46, 14);
		panel.add(lblPret);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(117, 213, 160, 20);
		panel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setBounds(117, 13, 160, 22);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID curs");
		lblNewLabel.setBounds(21, 16, 56, 16);
		panel.add(lblNewLabel);
		
		JLabel lblTipTest = new JLabel("Tip test");
		lblTipTest.setBounds(21, 250, 46, 14);
		panel.add(lblTipTest);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"teoretic", "practic"}));
		comboBox.setBounds(117, 246, 160, 22);
		panel.add(comboBox);
		
		JLabel lblIdAngajat = new JLabel("ID angajat");
		lblIdAngajat.setBounds(24, 284, 58, 14);
		panel.add(lblIdAngajat);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(117, 281, 160, 20);
		panel.add(textField_6);
		
		
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String sql= "INSERT INTO CURSURI (id_curs,nume_curs,durata_curs,data_curs,nr_participanti_curs,pret_curs,tip_test,angajati_id_angajat) VALUES (?,?,?,?,?,?,?,?)";
					PreparedStatement pst=con.prepareStatement(sql);
					pst.setString(1, textField_5.getText());
					pst.setString(2, textField.getText());
					pst.setString(3, textField_1.getText());
					pst.setString(4, textField_2.getText());
					pst.setString(5, textField_3.getText());
					pst.setString(6, textField_4.getText());
					String test;
					test=comboBox.getSelectedItem().toString();
					pst.setString(7, test); //test 
					pst.setString(8, textField_6.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Date inserate!");
					
					pst.close();
					
				}catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(105, 325, 89, 23);
		panel.add(btnNewButton);
		
		
		
		
		
		frmInsert.setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new InsertCurs();
	}
}
