package proiect;

import java.sql.*;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) throws SQLException {
        new GUI();  
        dbConnector();
    }

    static Connection con=null;
	public static Connection dbConnector() {
		String dburl="jdbc:oracle:thin:@bd-dc.cs.tuiasi.ro:1539:orcl";
        
        String username="bd052";
        String password="bd052";
        
        try {
			con=DriverManager.getConnection(dburl, username,password);
			System.out.println("Conectat la baza de date!");
			return con;
			//con.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
			
			return null;
		}
		
	}
}
