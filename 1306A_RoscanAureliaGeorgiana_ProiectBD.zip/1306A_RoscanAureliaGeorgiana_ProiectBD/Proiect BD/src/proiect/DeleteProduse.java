package proiect;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class DeleteProduse {
	static JTextField textField;
	
	Connection con=null;
	
	public DeleteProduse(){
        
		con=Main.dbConnector();
		
        JFrame frmInsert = new JFrame();
		frmInsert.setSize(315,173);
		
		frmInsert.setTitle("Delete");
		frmInsert.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 299, 129);
		frmInsert.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(117, 24, 160, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblIdAngajat = new JLabel("Cod Produs");
		lblIdAngajat.setBounds(21, 27, 58, 14);
		panel.add(lblIdAngajat);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String sql= "DELETE FROM TIPURI_PRODUSE WHERE cod_produs=?";
					PreparedStatement pst=con.prepareStatement(sql);
					pst.setString(1, textField.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Date sterse!");
					
					pst.close();
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnNewButton.setBounds(101, 82, 89, 23);
		panel.add(btnNewButton);
		
		frmInsert.setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new DeleteProduse();
	}
}
