package proiect;
import java.awt.*;
import javax.swing.*;

import net.proteanit.sql.DbUtils;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class GUI {
	Connection con=null;
	static JTable table;
	
	public GUI() throws SQLException{
		con=Main.dbConnector();
		JFrame frame = new JFrame();
		
		frame.setSize(1061,607);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Make-up Academy");
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(253, 245, 230));
		panel.setBounds(0, 0, 1043, 556);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(10, 11, 190, 534);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblMakeupAcademy = new JLabel("Make-up Academy");
		lblMakeupAcademy.setFont(new Font("Viner Hand ITC", Font.PLAIN, 19));
		lblMakeupAcademy.setBounds(20, 25, 180, 45);
		panel_1.add(lblMakeupAcademy);
		
		JPanel panelCursuri = new JPanel();
		panelCursuri.setBackground(Color.WHITE);
		panelCursuri.setBounds(210,505, 821, 40);
		panel.add(panelCursuri);
		panelCursuri.setVisible(false);
		panelCursuri.setLayout(null);
		
		JPanel panelAngajati = new JPanel();
		panelAngajati.setBackground(Color.WHITE);
		panelAngajati.setBounds(210, 505, 821, 40);
		panel.add(panelAngajati);
		panelAngajati.setVisible(false);
		panelAngajati.setLayout(null);
		
		JPanel panelProduse = new JPanel();
		panelProduse.setBackground(Color.WHITE);
		panelProduse.setBounds(210, 505, 821, 40);
		panel.add(panelProduse);
		panelProduse.setVisible(false);
		panelProduse.setLayout(null);
		
		JPanel panelCursanti = new JPanel();
		panelCursanti.setBackground(Color.WHITE);
		panelCursanti.setBounds(210, 505, 821, 40);
		panel.add(panelCursanti);
		panelCursanti.setVisible(false);
		panelCursanti.setLayout(null);
		
		JPanel panelProduseFolosite = new JPanel();
		panelProduseFolosite.setBackground(Color.WHITE);
		panelProduseFolosite.setBounds(210, 505, 821, 40);
		panel.add(panelProduseFolosite);
		panelProduseFolosite.setVisible(false);
		panelProduseFolosite.setLayout(null);
		
		JPanel panelProduseAchizitionate = new JPanel();
		panelProduseAchizitionate.setBackground(Color.WHITE);
		panelProduseAchizitionate.setBounds(210, 505, 821, 40);
		panel.add(panelProduseAchizitionate);
		panelProduseAchizitionate.setVisible(false);
		panelProduseAchizitionate.setLayout(null);
		
		JPanel panelCursCursanti = new JPanel();
		panelCursCursanti.setBackground(Color.WHITE);
		panelCursCursanti.setBounds(210, 505, 821, 40);
		panel.add(panelCursCursanti);
		panelCursCursanti.setVisible(false);
		panelCursCursanti.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(212, 11, 819, 471);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		//Object[] row= new Object[0];
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(37, 337, 120, 56);
		Image BTN = new ImageIcon(this.getClass().getResource("/FOLOSITE.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(BTN));
		panel_1.add(lblNewLabel);
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(true);
				panelProduseAchizitionate.setVisible(false);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM PRODUSE_FOLOSITE";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(false);
				panelProduseAchizitionate.setVisible(false);
				panelCursanti.setVisible(true);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM CURSANTI";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		lblNewLabel_1.setBounds(37, 270, 120, 56);
		Image BTN2 = new ImageIcon(this.getClass().getResource("/CURSANTI.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(BTN2));
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(false);
				panelProduseAchizitionate.setVisible(false);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(true);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM TIPURI_PRODUSE";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		lblNewLabel_3.setBounds(37, 205, 120, 56);
		Image BTN3 = new ImageIcon(this.getClass().getResource("/PRODUSE.png")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(BTN3));
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(false);
				panelProduseAchizitionate.setVisible(false);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(true);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM ANGAJATI";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		lblNewLabel_4.setBounds(37, 142, 120, 56);
		Image BTN4 = new ImageIcon(this.getClass().getResource("/ANGAJATI.png")).getImage();
		lblNewLabel_4.setIcon(new ImageIcon(BTN4));
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(false);
				panelProduseAchizitionate.setVisible(false);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(true);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM CURSURI";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		lblNewLabel_5.setBounds(37, 81, 120, 56);
		Image BTN5 = new ImageIcon(this.getClass().getResource("/cursuri.png")).getImage();
		lblNewLabel_5.setIcon(new ImageIcon(BTN5));
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				panelProduseFolosite.setVisible(false);
				panelProduseAchizitionate.setVisible(true);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(false);
				//System.out.println("merge");
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM PRODUSE_ACHIZITIONATE";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		lblNewLabel_6.setBounds(37, 404, 120, 56);
		Image BTN6 = new ImageIcon(this.getClass().getResource("/ACHIZ.png")).getImage();
		lblNewLabel_6.setIcon(new ImageIcon(BTN6));
		panel_1.add(lblNewLabel_6);
		
		JLabel lblNewLabel_6_1 = new JLabel("");
		lblNewLabel_6_1.setBounds(37, 471, 120, 56);
		lblNewLabel_6_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelProduseAchizitionate.setVisible(false);
				panelProduseFolosite.setVisible(false);
				panelCursanti.setVisible(false);
				panelProduse.setVisible(false);
				panelAngajati.setVisible(false);
				panelCursuri.setVisible(false);
				panelCursCursanti.setVisible(true);
				
				table.setVisible(true);
				try {
					String sql= "SELECT * FROM CURSANT_CURS_FK";
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet res=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(res));
					
				}catch(SQLException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		Image BTN6_1 = new ImageIcon(this.getClass().getResource("/CURS-CURSANTI.png")).getImage();
		lblNewLabel_6_1.setIcon(new ImageIcon(BTN6_1));
		panel_1.add(lblNewLabel_6_1);
		
		//1
		JLabel insertCurs = new JLabel("");
		insertCurs.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertCurs();
			}
		});
		insertCurs.setBounds(22, 0, 120, 39);
		Image img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertCurs.setIcon(new ImageIcon(img));
		panelCursuri.add(insertCurs);
				
		JLabel updateCurs = new JLabel("");
		updateCurs.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateCurs();
						
			}
		});
		updateCurs.setBounds(363, 0, 120, 39);
		Image img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateCurs.setIcon(new ImageIcon(img2));
		panelCursuri.add(updateCurs);
				
		JLabel deleteCurs = new JLabel("");
		deleteCurs.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteCurs();
			}
		});
		deleteCurs.setBounds(678, 0, 120, 39);
		Image img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteCurs.setIcon(new ImageIcon(img3));
		panelCursuri.add(deleteCurs);
		//2
		JLabel insertAngajati = new JLabel("");
		insertAngajati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertAngajati();
			}
		});
		insertAngajati.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertAngajati.setIcon(new ImageIcon(img));
		panelAngajati.add(insertAngajati);
				
		JLabel updateAngajati = new JLabel("");
		updateAngajati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateAngajati();
			}
		});
		updateAngajati.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateAngajati.setIcon(new ImageIcon(img2));
		panelAngajati.add(updateAngajati);
				
		JLabel deleteAngajati = new JLabel("");
		deleteAngajati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteAngajati();
			}
		});
		deleteAngajati.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteAngajati.setIcon(new ImageIcon(img3));
		panelAngajati.add(deleteAngajati);
		//3
		JLabel insertProduse = new JLabel("");
		insertProduse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertProduse();
			}
		});
		insertProduse.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertProduse.setIcon(new ImageIcon(img));
		panelProduse.add(insertProduse);
				
		JLabel updateProduse = new JLabel("");
		updateProduse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateProduse();
			}
		});
		updateProduse.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateProduse.setIcon(new ImageIcon(img2));
		panelProduse.add(updateProduse);
				
		JLabel deleteProduse = new JLabel("");
		deleteProduse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteProduse();
			}	
		});
		deleteProduse.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteProduse.setIcon(new ImageIcon(img3));
		panelProduse.add(deleteProduse);
		//4
		JLabel insertCursanti = new JLabel("");
		insertCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertCursanti();
			}
		});
		insertCursanti.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertCursanti.setIcon(new ImageIcon(img));
		panelCursanti.add(insertCursanti);
				
		JLabel updateCursanti = new JLabel("");
		updateCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateCursanti();
			}
		});
		updateCursanti.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateCursanti.setIcon(new ImageIcon(img2));
		panelCursanti.add(updateCursanti);
				
		JLabel deleteCursanti = new JLabel("");
		deleteCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteCursanti();
			}
		});
		deleteCursanti.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteCursanti.setIcon(new ImageIcon(img3));
		panelCursanti.add(deleteCursanti);
		//5
		JLabel insertProduseFolosite = new JLabel("");
		insertProduseFolosite.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertProdFol();
			}
		});
		insertProduseFolosite.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertProduseFolosite.setIcon(new ImageIcon(img));
		panelProduseFolosite.add(insertProduseFolosite);
				
		JLabel updateProduseFolosite = new JLabel("");
		updateProduseFolosite.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateProdFol();
			}
		});
		updateProduseFolosite.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateProduseFolosite.setIcon(new ImageIcon(img2));
		panelProduseFolosite.add(updateProduseFolosite);
				
		JLabel deleteProduseFolosite = new JLabel("");
		deleteProduseFolosite.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteProdFol();
			}
		});
		deleteProduseFolosite.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteProduseFolosite.setIcon(new ImageIcon(img3));
		panelProduseFolosite.add(deleteProduseFolosite);
		//6
		JLabel insertProduseAchizitionate = new JLabel("");
		insertProduseAchizitionate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertProdAchiz();
			}
		});
		insertProduseAchizitionate.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertProduseAchizitionate.setIcon(new ImageIcon(img));
		panelProduseAchizitionate.add(insertProduseAchizitionate);
				
		JLabel updateProduseAchizitionate = new JLabel("");
		updateProduseAchizitionate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateProdAchiz();
			}
		});
		updateProduseAchizitionate.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateProduseAchizitionate.setIcon(new ImageIcon(img2));
		panelProduseAchizitionate.add(updateProduseAchizitionate);
				
		JLabel deleteProduseAchizitionate = new JLabel("");
		deleteProduseAchizitionate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteProdAchiz();
			}
		});
		deleteProduseAchizitionate.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteProduseAchizitionate.setIcon(new ImageIcon(img3));
		panelProduseAchizitionate.add(deleteProduseAchizitionate);
		//7
		JLabel insertCursCursanti = new JLabel("");
		insertCursCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new InsertCursCursant();
			}
		});
		insertCursCursanti.setBounds(22, 0, 120, 39);
		img = new ImageIcon(this.getClass().getResource("/INSERT.png")).getImage();
		insertCursCursanti.setIcon(new ImageIcon(img));
		panelCursCursanti.add(insertCursCursanti);
				
		JLabel updateCursCursanti = new JLabel("");
		updateCursCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//new updateCursCursant();
				JOptionPane.showMessageDialog(null, "Nu se pot modifica datele din aceasta tabela!");
			}
		});
		updateCursCursanti.setBounds(363, 0, 120, 39);
		img2 = new ImageIcon(this.getClass().getResource("/UPDATE.png")).getImage();
		updateCursCursanti.setIcon(new ImageIcon(img2));
		panelCursCursanti.add(updateCursCursanti);
				
		JLabel deleteCursCursanti = new JLabel("");
		deleteCursCursanti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new DeleteCursCursanti();
			}
		});
		deleteCursCursanti.setBounds(678, 0, 120, 39);
		img3 = new ImageIcon(this.getClass().getResource("/DELETE.png")).getImage();
		deleteCursCursanti.setIcon(new ImageIcon(img3));
		panelCursCursanti.add(deleteCursCursanti);
				
        frame.setVisible(true);
	}
	
}
